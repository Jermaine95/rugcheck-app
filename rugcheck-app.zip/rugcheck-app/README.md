# Rug Checker

A Solana token risk-checker: paste a contract address, get a red/yellow/green
verdict based on liquidity lock, mint/freeze authority, holder concentration,
and transfer fees — pulled live from the GoPlus Security API.

## Why this needs a backend (short version)

GoPlus's API isn't set up to be called directly from a browser (no CORS
headers for arbitrary origins). `api/check.js` is a tiny serverless function
that makes the GoPlus call **from the server**, where CORS doesn't apply, and
hands the result back to the frontend. This is the standard pattern for any
frontend that needs to call an API that doesn't allow direct browser access.

## Deploying (Vercel — free, ~5 minutes)

1. **Create a GitHub repo** and push this folder to it (or use Vercel's CLI
   to deploy without GitHub — see step 4).

2. **Sign up / log in at [vercel.com](https://vercel.com)** — free tier is
   enough for this.

3. **Import the project**: on your Vercel dashboard, click "Add New →
   Project", connect your GitHub repo, and click Deploy. Vercel
   auto-detects this as a Vite project and the `api/` folder as serverless
   functions — no configuration needed.

   **OR**, without GitHub, from this folder run:
   ```
   npm install -g vercel
   vercel
   ```
   and follow the prompts. Vercel will give you a live URL in under a minute.

4. **That's it.** Once deployed, your app is live at something like
   `https://rugcheck-yourname.vercel.app`, and `/api/check` is automatically
   live alongside it — no separate backend hosting needed.

## Running locally first (optional but recommended)

```
npm install
vercel dev
```

`vercel dev` runs both the frontend AND the `/api` serverless functions
together locally, which regular `npm run dev` (Vite alone) does not — Vite
alone won't know how to handle `/api/check`.

If you don't have the Vercel CLI: `npm install -g vercel` first.

## Testing it

Once running (locally or deployed), paste a real Solana token address into
the scanner, e.g.:

- USDC: `EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v` (should come back clean)
- BONK: `DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263`

If GoPlus is unreachable or rate-limits you, the app automatically falls
back to demo data and shows a clear amber banner saying so — it will never
silently show fake data as if it were real.

## What's NOT wired up yet

- No true honeypot/sell-simulation (GoPlus's Solana endpoint doesn't offer
  one the way their EVM endpoint does) — `transfer_fee` is used as an
  approximation, labeled as such in the UI.
- Contract age isn't returned by this GoPlus endpoint — shown as "not
  provided" rather than faked.
- No rate limiting or caching on `/api/check` yet — fine for personal
  testing, worth adding before any public/shared use (GoPlus's free tier
  has its own rate limits you could hit).
- No token/coin functionality here at all — this is just the checker tool.
